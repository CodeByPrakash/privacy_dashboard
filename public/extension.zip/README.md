# Privacy Dashboard Tracker Extension

## Load in Chrome
1. Open chrome://extensions
2. Enable Developer Mode
3. Load unpacked
4. Select the `extension` folder

## Configure
Open the extension options and set:
- API Base URL (e.g. http://localhost:3000)
- Extension API Key (from `.env`)
- Student ID (value of `users.student_id`)
